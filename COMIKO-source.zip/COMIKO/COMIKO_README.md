# COMIKO

COMIKO is a unified Android manga + music experience built from the supplied Velune source tree, with a new manga-first surface and a local CBZ/ZIP reader. The existing Velune Media3/ExoPlayer playback stack, browsing, queue, mini-player and full player remain in the project.

## What is included
- **Manga tab:** import a `.cbz`/`.zip` chapter containing JPG/JPEG/PNG/WebP/AVIF pages and read it in a vertical reader.
- **Music tab:** the supplied Velune music home/browsing/player remains available.
- **Liquid-glass UI:** COMIKO uses the glass navigation/player infrastructure already present in Velune and adds translucent glass manga cards.
- **Background playback:** inherited from Velune's Media3 playback service.

## Important implementation note
The supplied Mihon asset is an APK, not Mihon's source tree. An APK cannot be cleanly merged into this Gradle project as source. Therefore this build adds a native local manga reader rather than pretending to contain the full Mihon source, source-extension system, tracker stack, and downloader.

Mihon itself is Apache-2.0 licensed; the official project describes local reading, configurable readers, tracking, categories, updates and backups. The project can be extended later by importing the official Mihon source modules instead of decompiling the APK.

## Build
Open the project in Android Studio (JDK 21 / Android SDK 36) and build the `universalDebug` variant. The uploaded Velune archive did not include `gradle-wrapper.properties`, so Android Studio/Gradle sync is the recommended build route.

## Attribution
- Velune source supplied by the user; GPL-3.0.
- Mihon is an independent Apache-2.0 project; COMIKO does not include decompiled Mihon code.

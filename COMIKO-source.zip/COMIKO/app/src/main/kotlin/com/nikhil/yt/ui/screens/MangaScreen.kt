package com.nikhil.yt.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.nikhil.yt.R
import com.kyant.backdrop.backdrops.rememberCanvasBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

private data class MangaPage(val file: File)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MangaScreen() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var pages by remember { mutableStateOf<List<MangaPage>>(emptyList()) }
    var title by remember { mutableStateOf("Your manga shelf") }
    var importing by remember { mutableStateOf(false) }
    var reader by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importing = true
            scope.launch {
                val result = withContext(Dispatchers.IO) { importChapter(context, uri) }
                title = result.first
                pages = result.second
                importing = false
                reader = pages.isNotEmpty()
            }
        }
    }

    if (reader && pages.isNotEmpty()) {
        MangaReader(title = title, pages = pages, onClose = { reader = false })
        return
    }

    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("COMIKO", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                        Text("Manga + music", style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = { picker.launch(arrayOf("application/zip", "application/x-cbz", "application/octet-stream")) }) {
                        Icon(painterResource(android.R.drawable.ic_menu_add), contentDescription = "Import chapter")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Box(
            Modifier.fillMaxSize().padding(padding).background(
                Brush.radialGradient(
                    colors = if (dark) listOf(Color(0xFF271B45), Color(0xFF0A0A10), Color(0xFF050507))
                    else listOf(Color(0xFFE6D9FF), Color(0xFFF8F6FF), Color.White)
                )
            )
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(12.dp))
                LiquidGlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(22.dp)) {
                        Text("Read without leaving your vibe", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Open a CBZ/ZIP chapter and COMIKO will turn it into a clean vertical reader. Your Velune music player stays available underneath.", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { picker.launch(arrayOf("application/zip", "application/x-cbz", "application/octet-stream")) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) { Text(if (importing) "Importing…" else "Open chapter") }
                            OutlinedButton(onClick = { reader = pages.isNotEmpty() }, enabled = pages.isNotEmpty()) { Text("Continue") }
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                if (pages.isEmpty()) {
                    LiquidGlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp)) {
                            Text("Nothing imported yet", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Text("COMIKO supports image pages packaged as .cbz or .zip. Pick a chapter to start reading.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    LiquidGlassCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                                Text("M", fontSize = 28.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(title, fontWeight = FontWeight.Bold)
                                Text("${pages.size} pages • ready to read", style = MaterialTheme.typography.labelMedium)
                            }
                            Button(onClick = { reader = true }) { Text("Read") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    val backdrop = rememberCanvasBackdrop { drawRect(Color.Black.copy(alpha = 0.16f), size = size) }
    Box(
        modifier
            .clip(shape)
            .then(
                Modifier.drawBackdrop(
                    backdrop = backdrop,
                    shape = { shape },
                    effects = { vibrancy(); blur(28.dp.toPx()); lens(16.dp.toPx(), 28.dp.toPx()) },
                    onDrawSurface = {
                        drawRect(Color.White.copy(alpha = 0.075f))
                    }
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
    ) { content() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MangaReader(title: String, pages: List<MangaPage>, onClose: () -> Unit) {
    Scaffold(
        containerColor = Color.Black,
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onClose) { Icon(painterResource(android.R.drawable.ic_menu_close_clear_cancel), contentDescription = "Close reader", tint = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black.copy(alpha = .86f), titleContentColor = Color.White)
            )
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).background(Color.Black)) {
            items(pages, key = { it.file.name }) { page ->
                AsyncImage(
                    model = page.file,
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth(),
                    contentScale = ContentScale.FillWidth
                )
            }
        }
    }
}

private fun importChapter(context: Context, uri: Uri): Pair<String, List<MangaPage>> {
    return try {
        val root = File(context.cacheDir, "comiko_chapters/${System.currentTimeMillis()}").apply { mkdirs() }
        val archive = File(root, "chapter.zip")
        context.contentResolver.openInputStream(uri)?.use { input -> archive.outputStream().use { output -> input.copyTo(output) } }
            ?: return "Unable to open chapter" to emptyList()
        val pagesDir = File(root, "pages").apply { mkdirs() }
        ZipFile(archive).use { zip ->
            zip.entries().asSequence()
                .filter { !it.isDirectory && it.name.substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "webp", "avif") }
                .sortedBy { it.name.lowercase() }
                .forEachIndexed { index, entry ->
                    val ext = entry.name.substringAfterLast('.', "jpg").lowercase()
                    val out = File(pagesDir, "%04d.%s".format(index + 1, ext))
                    zip.getInputStream(entry).use { input -> out.outputStream().use { output -> input.copyTo(output) } }
                }
        }
        val list = pagesDir.listFiles()?.sortedBy { it.name }?.map(::MangaPage).orEmpty()
        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.')?.ifBlank { "Imported chapter" } ?: "Imported chapter"
        name to list
    } catch (_: Exception) {
        "Unable to import chapter" to emptyList()
    }
}
